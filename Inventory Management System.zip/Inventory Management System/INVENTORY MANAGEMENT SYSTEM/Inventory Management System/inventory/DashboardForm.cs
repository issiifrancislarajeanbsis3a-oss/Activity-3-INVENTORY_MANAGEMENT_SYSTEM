using System;
using System.Windows.Forms;

namespace inventory
{
    public partial class DashboardForm : Form
    {
        private readonly int currentUserId;
        private readonly Form signInForm;
        private bool loggedOut = false;

       
        public DashboardForm()
        {
            InitializeComponent();
        }

        public DashboardForm(int userId, string fullName, string role, Form signIn)
        {
            InitializeComponent();
            currentUserId = userId;
            signInForm = signIn;
        }


        private void btnLogout_Click(object sender, EventArgs e)
        {
            Database.LogActivity(currentUserId, "Signed out");
            loggedOut = true;
            if (signInForm != null) signInForm.Show();
            this.Close();
        }

        private void DashboardForm_FormClosed(object sender, FormClosedEventArgs e)
        {

            if (!loggedOut) Application.Exit();
        }
    }
}
