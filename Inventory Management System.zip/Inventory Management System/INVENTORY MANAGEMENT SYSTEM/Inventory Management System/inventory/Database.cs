using System;
using System.Data.OleDb;
using System.IO;
using System.Security.Cryptography;
using System.Text;

namespace inventory
{
    public static class Database
    {
        // sampledb.accdb sits in the project folder (two levels above bin\Debug), same as in the video
        public static readonly string DBpATH = Path.GetFullPath(
            Path.Combine(AppDomain.CurrentDomain.BaseDirectory, @"..\..\sampledb.accdb"));

        private static readonly string connectionString =
            @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + DBpATH + ";Persist Security Info=False;";

        public static OleDbConnection GetConnection()
        {
            return new OleDbConnection(connectionString);
        }

        // ---- kept from your original project so Sign In / Register / Dashboard keep working ----

        public static string HashPassword(string password)
        {
            using (SHA256 sha = SHA256.Create())
            {
                byte[] bytes = sha.ComputeHash(Encoding.UTF8.GetBytes(password));
                StringBuilder sb = new StringBuilder();
                foreach (byte b in bytes) sb.Append(b.ToString("x2"));
                return sb.ToString();
            }
        }

        public static void LogActivity(int userId, string action)
        {
            try
            {
                using (OleDbConnection con = GetConnection())
                using (OleDbCommand cmd = new OleDbCommand(
                    "INSERT INTO ActivityLogs (UserID, ActionText, LogDate) VALUES (?, ?, ?)", con))
                {
                    cmd.Parameters.Add("?", OleDbType.Integer).Value = userId;
                    cmd.Parameters.Add("?", OleDbType.VarWChar).Value = action;
                    cmd.Parameters.Add("?", OleDbType.Date).Value = DateTime.Now;
                    con.Open();
                    cmd.ExecuteNonQuery();
                }
            }
            catch { /* logging should never crash the app */ }
        }
    }
}
